Report.ipynb,Report.html - там все проделанная работа по сессии и вывод
(в Report.html - Содержиться все без возможности запуска, а в Report.ipynb - там уже
с ячейками запуска)

Readme.txt - Доп коментарии о файлах

Data.zip - Хранятся все данные о проделанной работе
 Внитри архива находятся файлы:
      Report.ipynb - написано выше
      Report.html - написано выше
      Readme.txt - доп информация
      expenses.csv - первоначальные данные
      orders.csv - первоначальные данные
      visatation.csv - первоначальные данные
      expenses_new.csv - новый dataframe
      orders_new.csv - новый dataframe
      visatation_new.csv - новый dataframe
      expenses.sql - sql скрипт для expenses dataframe
      orders.sql - sql скрипт для orders dataframe
      visatation.sql - sql скрипт для visatation dataframe
