Report.ipynb,Report.html - там все проделанная работа по сессии и вывод
(в Report.html - Содержиться все без возможности запуска, а в Report.ipynb - там уже
с ячейками запуска)

Readme.txt - Доп коментарии о файлах

Data.zip - Хранятся все данные о проделанной работе
 Внитри архива находятся файлы:
      Report.ipynb - написано выше
      Report.html - написано выше
      Readme.txt - доп информация
      expenses_new.csv - dataframe
      orders_new.csv - dataframe
      visatation_new.csv - dataframe
      user_data.csv - новый dataframe
